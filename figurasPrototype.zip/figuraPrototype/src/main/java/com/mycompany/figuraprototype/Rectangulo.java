package com.mycompany.figuraprototype;

public class Rectangulo extends Figura{
    private float lado;
    private float ancho;

    private String color;
    
    public Rectangulo(float lado, String color, float ancho){
        this.lado = lado;
        this.ancho = ancho;
        this.color = color;
    }

    public float getLado() {
        return lado;
    }

    public void setLado(float lado) {
        this.lado = lado;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public float getAncho() {
        return ancho;
    }

    public void setAncho(float ancho) {
        this.ancho = ancho;
    }
    
    @Override
    public Rectangulo clonar() {
        Rectangulo clon = new Rectangulo(this.lado, this.color, this.ancho);
        clon.setPrototipoOrigen(this); //Asigna el origen
        return clon;
    }

    @Override
    public void dibujar() {
        System.out.println("Dibujando un rectangulo de color "+color+", de lado "+lado+" y ancho "+ancho);
    }
    
}

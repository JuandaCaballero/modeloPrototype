package com.mycompany.figuraprototype;

public interface iFigura {
    iFigura clonar();
    public void dibujar();
}

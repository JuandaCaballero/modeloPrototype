package com.mycompany.figuraprototype;

import java.awt.Graphics;

public interface iFigura{
    void dibujar(Graphics g);
    iFigura clonar();
    void mover(int dx, int dy);
}

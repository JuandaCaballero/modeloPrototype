package com.mycompany.figuraprototype;

public class Circulo extends Figura{
    private float radio;
    private String color;
    
    public Circulo(float radio, String color){
        this.radio = radio;
        this.color = color;
    }

    public float getRadio() {
        return radio;
    }

    public void setRadio(float radio) {
        this.radio = radio;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
    
    @Override
    public Circulo clonar() {
        Circulo clon = new Circulo(this.radio, this.color);
        clon.setPrototipoOrigen(this); //Asigna el origen
        return clon;
    }

    @Override
    public void dibujar() {
        System.out.println("Dibujando un circulo de color "+color+" y de radio "+radio);
    }
    
}

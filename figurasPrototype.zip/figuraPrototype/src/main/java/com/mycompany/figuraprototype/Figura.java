package com.mycompany.figuraprototype;

public abstract class Figura implements iFigura{
    //Para tener el "linaje" de las figuras (Quien esta dentro de quien)
    protected Figura prototipoOrigen;
    
    public Figura getPrototipoOrigen(){
        return prototipoOrigen;
    }
    
    public void setPrototipoOrigen(Figura prototipo){
        this.prototipoOrigen = prototipo;
    }
    
    public void mostrarLinaje(){
        Figura actual = this;
        System.out.print("Orden: ");
        while (actual != null){
            System.out.print(actual.getClass().getSimpleName()+" <- ");
            actual = actual.getPrototipoOrigen(); //Tomamos actual como ahora el padre
        }
        System.out.println("");
    }
    
}

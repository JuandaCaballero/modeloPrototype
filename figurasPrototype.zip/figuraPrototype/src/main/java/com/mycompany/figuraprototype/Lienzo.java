package com.mycompany.figuraprototype;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class Lienzo extends JPanel {
    private List<iFigura> figuras = new ArrayList<>();

    public void agregarFigura(iFigura f) {
        figuras.add(f);
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        for (iFigura f : figuras) {
            f.dibujar(g);
        }
    }
}


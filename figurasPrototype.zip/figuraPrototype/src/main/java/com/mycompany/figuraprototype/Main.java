package com.mycompany.figuraprototype;

public class Main {

    public static void main(String[] args) {
        //Creacion de figuras para la casa
        Cuadrado cuadrado1 = new Cuadrado(5, "naranja");
        Cuadrado cuadrado2 = cuadrado1.clonar();
        Cuadrado cuadrado3 = cuadrado1.clonar();
        Circulo circulo1 = new Circulo(2, "verde");
        Circulo circulo2 = circulo1.clonar();
        Rectangulo rectangulo1 = new Rectangulo(2, "verde", 5);
        Triangulo triangulo1 = new Triangulo(2, "rosado", 7);
        
        //Asignacion de padres 
        circulo1.setPrototipoOrigen(cuadrado2);
        circulo2.setPrototipoOrigen(cuadrado3);
        cuadrado2.setPrototipoOrigen(cuadrado1);
        rectangulo1.setPrototipoOrigen(cuadrado1);
        
        
        circulo1.mostrarLinaje();
        circulo2.mostrarLinaje();
        cuadrado1.mostrarLinaje();
        cuadrado2.mostrarLinaje();
        cuadrado3.mostrarLinaje();
        triangulo1.mostrarLinaje();
        rectangulo1.mostrarLinaje();
        
    }
}

package com.mycompany.figuraprototype;

import javax.swing.*;
import java.awt.*;

public class Main{


    public static void main(String[] args) {
        JFrame frame = new JFrame("Casa con Prototype y Compuesto");
        Lienzo lienzo = new Lienzo();

        frame.add(lienzo);
        frame.setSize(1000, 720);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
        
        FiguraCompuesta casa = new FiguraCompuesta();
        FiguraCompuesta ventana = new FiguraCompuesta();
        
        ventana.agregarFigura("marco", new Rectangulo(180, 250, 60, 60, Color.WHITE));
        ventana.agregarFigura("estilo", new Circulo(185, 255, 25, Color.BLACK));
       
        //Pared principal
        casa.agregarFigura("pared", new Rectangulo(150, 200, 300, 300, Color.LIGHT_GRAY));

        // Techo
        int[] x = {150, 450, 300};
        int[] y = {200, 200, 100};
        casa.agregarFigura("techo", new Triangulo(x, y, Color.RED));
        
        // Puerta
        casa.agregarFigura("puerta", new Rectangulo(270, 400, 60, 100,Color.GREEN));
        
        // Ventanas
        casa.agregarFigura("ventana1", ventana);
        casa.agregarFigura("ventana2", ventana.clonar());
        
        iFigura ventana2 = casa.getFigura("ventana2");
        if (ventana2 != null) {
            ventana2.mover(175, 0); 
            lienzo.repaint();
        }
        
        lienzo.agregarFigura(casa);
        
        FiguraCompuesta casa2 = (FiguraCompuesta) casa.clonar();
        casa2.mover(400, 0);
        lienzo.agregarFigura(casa2);
        lienzo.repaint();
        
    }
}


package com.mycompany.figuraprototype;

public class Triangulo extends Figura{
    private float alto;
    private float ancho;

    private String color;
    
    public Triangulo(float alto, String color, float ancho){
        this.alto = alto;
        this.color = color;
        this.ancho = ancho;
    }

    public float getAlto() {
        return alto;
    }

    public void setAlto(float alto) {
        this.alto = alto;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public float getAncho() {
        return ancho;
    }

    public void setAncho(float ancho) {
        this.ancho = ancho;
    }
    
    @Override
    public Triangulo clonar() {
        Triangulo clon = new Triangulo(this.alto, this.color, this.ancho);
        clon.setPrototipoOrigen(this); //Asigna el origen
        return clon;
    }

    @Override
    public void dibujar() {
        System.out.println("Dibujando un rectangulo de color "+color+", de lado "+alto+" y ancho "+ancho);
    }
    
}

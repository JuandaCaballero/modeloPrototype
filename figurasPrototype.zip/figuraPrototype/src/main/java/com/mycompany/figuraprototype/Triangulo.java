package com.mycompany.figuraprototype;

import java.awt.*;

public class Triangulo implements iFigura {
    private int[] x;
    private int[] y;
    private Color color;

    public Triangulo(int[] x, int[] y, Color color) {
        this.x = x;
        this.y = y;
        this.color = color;
    }

    public int[] getX() {
        return x;
    }

    public void setX(int[] x) {
        this.x = x;
    }

    public int[] getY() {
        return y;
    }

    public void setY(int[] y) {
        this.y = y;
    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    
    
    @Override
    public void dibujar(Graphics g) {
        g.setColor(color);
        g.fillPolygon(x, y, 3);
        g.setColor(Color.BLACK);
        g.drawPolygon(x, y, 3);
    }

    @Override
    public iFigura clonar() {
        return new Triangulo(x.clone(), y.clone(), color);
    }

    @Override
    public void mover(int dx, int dy) {
        for (int i = 0; i < x.length; i++) {
            x[i] += dx;
            y[i] += dy;
        }
    }
}


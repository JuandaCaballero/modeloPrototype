package com.mycompany.figuraprototype;

public class Cuadrado extends Figura{
    private float lado;
    private String color;
    
    public Cuadrado(float lado, String color){
        this.lado = lado;
        this.color = color;
    }

    public float getLado() {
        return lado;
    }

    public void setLado(float lado) {
        this.lado = lado;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    
    @Override
    public Cuadrado clonar() {
        Cuadrado clon = new Cuadrado(this.lado, this.color);
        clon.setPrototipoOrigen(this); //Asigna el origen
        return clon;
    }

    @Override
    public void dibujar() {
        System.out.println("Dibujando un cuadrado de color "+color+" y de lado "+lado);
    }
    
}

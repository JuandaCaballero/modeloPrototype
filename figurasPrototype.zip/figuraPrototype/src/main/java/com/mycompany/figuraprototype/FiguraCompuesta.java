package com.mycompany.figuraprototype;

import java.awt.*;
import java.util.LinkedHashMap;
import java.util.Map;

public class FiguraCompuesta implements iFigura {
    private Map<String, iFigura> partes = new LinkedHashMap<>();

    // Agregar figura con nombre
    public void agregarFigura(String nombre, iFigura f) {
        partes.put(nombre, f);
    }

    // Eliminar figura por nombre
    public void eliminarFigura(String nombre) {
        partes.remove(nombre);
    }
    
    public void editarFigura(String nombre, iFigura nuevaFigura) {
        if (partes.containsKey(nombre)) {
            partes.put(nombre, nuevaFigura);
        }
    }
    
    // Obtener figura por nombre
    public iFigura getFigura(String nombre) {
        return partes.get(nombre);
    }

    @Override
    public void dibujar(Graphics g) {
        for (iFigura f : partes.values()) {
            f.dibujar(g);
        }
    }

    @Override
    public iFigura clonar() {
        FiguraCompuesta copia = new FiguraCompuesta();
        for (Map.Entry<String, iFigura> entry : partes.entrySet()) {
            copia.agregarFigura(entry.getKey(), entry.getValue().clonar());
        }
        return copia;
    }

    @Override
    public void mover(int dx, int dy) {
        for (iFigura f : partes.values()) {
            f.mover(dx, dy);
        }
    }
}
